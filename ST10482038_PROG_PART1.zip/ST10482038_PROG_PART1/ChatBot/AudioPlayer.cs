using System;
using System.Reflection;
using System.Linq;
using System.Threading.Tasks;

namespace ChatbotProject
{
    public class AudioPlayer
    {
        private object? _speechSynth = null;
        private MethodInfo? _speakMethod = null;
        private MethodInfo? _speakAsyncMethod = null;
        private object? _sapiVoice = null;

        public AudioPlayer()
        {
            try
            {
                var asm = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(a => a.GetName().Name == "System.Speech");
                if (asm == null) { try { asm = Assembly.Load("System.Speech"); } catch { asm = null; } }

                if (asm != null)
                {
                    var synthType = asm.GetType("System.Speech.Synthesis.SpeechSynthesizer");
                    if (synthType != null)
                    {
                        _speechSynth = Activator.CreateInstance(synthType);
                        _speakMethod = synthType.GetMethod("Speak", new[] { typeof(string) });
                        _speakAsyncMethod = synthType.GetMethod("SpeakAsync", new[] { typeof(string) });
                    }
                }
            }
            catch { _speechSynth = null; }

            if (_speechSynth == null)
            {
                try
                {
                    var t = Type.GetTypeFromProgID("SAPI.SpVoice");
                    if (t != null) _sapiVoice = Activator.CreateInstance(t);
                }
                catch { _sapiVoice = null; }
            }
        }

        public void Speak(string message)
        {
            if (_speechSynth != null && _speakMethod != null)
            {
                _speakMethod.Invoke(_speechSynth, new object[] { message });
                return;
            }
            if (_sapiVoice != null)
            {
                try { dynamic d = _sapiVoice; d.Speak(message); } catch { }
            }
        }

        public void SpeakAsync(string message)
        {
            if (string.IsNullOrWhiteSpace(message)) return;
            // Do not speak menu or option listings — check for common menu phrases
            string lower = message.ToLowerInvariant();
            if (lower.Contains("cybersecurity services menu") || lower.Contains("password safety") || lower.Contains("phishing awareness") || lower.Contains("safe browsing") || lower.Contains("general security") || lower.Contains("exit application"))
            {
                return;
            }
            if (_speechSynth != null && _speakAsyncMethod != null)
            {
                try { _speakAsyncMethod.Invoke(_speechSynth, new object[] { message }); return; } catch { }
            }
            if (_sapiVoice != null)
            {
                try { dynamic d = _sapiVoice; d.Speak(message, 1); return; } catch { }
            }
            Task.Run(() => Speak(message));
        }
    }
}
