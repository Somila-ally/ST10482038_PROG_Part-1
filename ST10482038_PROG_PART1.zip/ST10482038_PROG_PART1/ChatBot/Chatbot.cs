using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace ChatbotProject
{
    public class Chatbot
    {
        private readonly Random _random = new Random();
        private readonly User _user;

        // memory
        private readonly Dictionary<string, string> _memory = new Dictionary<string, string>
        {
            { "lastTopic", string.Empty },
            { "interest", string.Empty }
        };

        private readonly Dictionary<string, string> _keywordMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "password", "password" }, { "pass", "password" }, { "credentials", "password" },
            { "phishing", "phishing" }, { "scam", "phishing" }, { "email", "phishing" },
            { "browsing", "browsing" }, { "browser", "browsing" }, { "website", "browsing" }, { "safe", "browsing" },
            { "general", "general" }, { "security", "general" },
            { "privacy", "privacy" }, { "data", "privacy" }
        };

        private readonly List<string> _worriedKeywords = new List<string> { "worried", "scared", "afraid", "concerned", "anxious", "confused" };

        private readonly Dictionary<string, List<string>> _tipsDatabase = new Dictionary<string, List<string>>
        {
            { "password", new List<string> {
                "Use a passphrase: Combine 3-4 random words (e.g., 'CoffeeTableMountain2024') for a strong, memorable password.",
                "Never reuse passwords across critical accounts like email and banking.",
                "Enable Two-Factor Authentication (2FA) wherever possible to add an extra layer of security."
            }},
            { "phishing", new List<string> {
                "Be suspicious of emails creating urgency, like 'Your account will be closed'. Verify directly with the company.",
                "Always check the sender's email address, not just the display name. Look for misspellings.",
                "Never click links in unsolicited emails. Hover over them to see the actual destination URL."
            }},
            { "browsing", new List<string> {
                "Look for the padlock icon and 'https://' in the address bar before entering sensitive data.",
                "Keep your browser updated to patch security vulnerabilities automatically.",
                "Avoid using public Wi-Fi for banking. If you must, use a VPN to encrypt your connection."
            }},
            { "general", new List<string> {
                "Regularly back up your data to an external drive or cloud service to protect against ransomware.",
                "Update your operating system and apps frequently to fix security holes.",
                "Review your social media privacy settings to control who sees your personal information."
            }},
            { "privacy", new List<string> {
                "Review app permissions on your phone. Does a flashlight app really need your location?",
                "Use private browsing or privacy-focused search engines to reduce tracking.",
                "Be mindful of what you share on social media; oversharing can lead to identity theft."
            }}
        };

        public Chatbot(User user)
        {
            _user = user;
        }

        public void DisplayLogo()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            string logo = @"
   ███████╗ ██████╗ ███╗   ██╗ █████╗ ██╗     
   ██╔════╝██╔═══██╗████╗  ██║██╔══██╗██║     
   ███████╗██║   ██║██╔██╗ ██║███████║██║     
   ╚════██║██║   ██║██║╚██╗██║██╔══██║██║     
   ███████║╚██████╔╝██║ ╚████║██║  ██║███████╗
   ╚══════╝ ╚═════╝ ╚═╝  ╚══╝╚═╝  ╚═╝╚══════╝
            ";
            Console.WriteLine(logo);
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("             >>> Chat with Somila <<<");
            Console.WriteLine("                 [Cybersecurity Bot]");
            Console.ResetColor();
        }

        public void DisplayMenu(string name)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n==================================================");
            Console.WriteLine($"           WELCOME, {name.ToUpper()}!");
            Console.WriteLine("==================================================");
            Console.WriteLine("       CYBERSECURITY SERVICES MENU");
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine("  1. Password Safety Tips");
            Console.WriteLine("  2. Phishing Awareness");
            Console.WriteLine("  3. Safe Browsing Practices");
            Console.WriteLine("  4. General Security Advice");
            Console.WriteLine("  5. Exit Application");
            Console.WriteLine("\nYou can also type questions directly (e.g., 'I am worried about scams').");
            Console.WriteLine("--------------------------------------------------");
            Console.ResetColor();
        }

        public string GetResponse(string input)
        {
            string inputLower = input.ToLower();
            string sentimentPrefix = string.Empty;
            bool isWorried = _worriedKeywords.Any(k => inputLower.Contains(k));
            if (isWorried)
            {
                sentimentPrefix = "I understand that this can be concerning. Don't worry, I'm here to help you. ";
            }

            if (inputLower.Contains("another tip") || inputLower.Contains("tell me more") || inputLower.Contains("more info"))
            {
                if (!string.IsNullOrEmpty(_memory["lastTopic"]))
                {
                    return sentimentPrefix + GetTipForTopic(_memory["lastTopic"]);
                }
                return "Which topic would you like more tips on? (password, phishing, browsing)";
            }

            string detectedTopic = null;
            foreach (var pair in _keywordMap)
            {
                if (inputLower.Contains(pair.Key))
                {
                    detectedTopic = pair.Value; break;
                }
            }

            if (input == "1") detectedTopic = "password";
            else if (input == "2") detectedTopic = "phishing";
            else if (input == "3") detectedTopic = "browsing";
            else if (input == "4") detectedTopic = "general";

            if (detectedTopic != null)
            {
                _memory["lastTopic"] = detectedTopic;
                if (detectedTopic == "privacy" || detectedTopic == "password") _memory["interest"] = detectedTopic;

                string memoryPrefix = string.Empty;
                if (!string.IsNullOrEmpty(_memory["interest"]) && _memory["interest"] != detectedTopic)
                {
                    // link topics if needed
                }
                else if (!string.IsNullOrEmpty(_memory["interest"]))
                {
                    memoryPrefix = $"Since you are interested in {_memory["interest"]}, this is particularly relevant for you. ";
                }

                return sentimentPrefix + memoryPrefix + GetTipForTopic(detectedTopic);
            }

            // Basic conversational QA
            if (inputLower.Contains("how are you")) return "I'm a bot, but I'm functioning as expected. Thanks for asking!";
            if (inputLower.Contains("purpose") || inputLower.Contains("what do you do")) return "I provide cybersecurity tips and guidance to help you stay safe online.";

            return "I'm not sure I understand. You can ask me about passwords, phishing, browsing, or general security tips.";
        }

        private string GetTipForTopic(string topic)
        {
            if (_tipsDatabase.ContainsKey(topic))
            {
                var tips = _tipsDatabase[topic];
                return tips[_random.Next(tips.Count)];
            }
            return "I don't have tips for that topic yet.";
        }

        public void TypeEffect(string message, int speed = 20)
        {
            if (speed <= 0) { Console.WriteLine(message); return; }
            int i = 0;
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(speed);
                try
                {
                    if (Console.KeyAvailable)
                    {
                        var key = Console.ReadKey(true);
                        if (key.Key == ConsoleKey.Enter)
                        {
                            Console.Write(message.Substring(i + 1));
                            break;
                        }
                    }
                }
                catch { }
                i++;
            }
            Console.WriteLine();
        }

        public void DisplayBotResponse(string response)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("\nBot: ");
            TypeEffect(response, 15);
            Console.ResetColor();
        }
    }
}
