namespace ChatbotProject
{
    public class User
    {
        public string Name { get; set; } = "User";
    }
}
