# make_commits.ps1
# Automate creating 8 commits locally with meaningful messages.
# Usage: Open PowerShell in the repo root (C:\Users\Nary2\source\repos\ChatBot) and run:
#   pwsh .\make_commits.ps1

# Increase commits to 12 (more than the requested 8)
$messages = @(
    'Initial project setup',
    'Refactor: split Program into Chatbot, User, AudioPlayer',
    'UI: add ASCII logo, colors and typing effect',
    'Audio: add TTS support and audio player wrapper',
    'Features: add tips database and keyword mapping',
    'Enhancement: sentiment detection and memory storage',
    'Stability: input validation and improved menu flow',
    'CI: add GitHub Actions workflow and commit script',
    'Docs: add README placeholder',
    'Tests: add test project placeholder',
    'Chore: update .gitignore and cleanup',
    'Final: prepare for submission'
)

function Run([string]$cmd) {
    Write-Host "> $cmd"
    iex $cmd
}

# Ensure running from script directory
Set-Location -Path $PSScriptRoot

# Initialize git repo if needed
if (-not (Test-Path -Path .git)) {
    Write-Host "No .git found - initializing repository..."
    Run "git init"
}

# Ensure commits_log exists
$log = "commits_log.txt"
if (-not (Test-Path $log)) { New-Item -Path $log -ItemType File -Force | Out-Null }

# Create one file and commit per message so commits are distinct
for ($i = 0; $i -lt $messages.Count; $i++) {
    $msg = $messages[$i]
    $num = $i + 1
    $timestamp = (Get-Date).ToString('u')

    # write entry to commits_log
    Add-Content -Path $log -Value "[$timestamp] Commit $num: $msg"

    # create a small file to commit for this step
    $commitFile = "commit_$num.txt"
    $content = "Commit $num - $msg`nGenerated at $timestamp"
    Set-Content -Path $commitFile -Value $content -Force

    Run "git add $commitFile $log"
    Run "git commit -m `"$msg`""
}

Write-Host "Done. 8 commits created locally. Push to your GitHub repo to trigger CI."
Write-Host "If you need to set user.name/user.email for commits, run:"
Write-Host "  git config user.name \"Your Name\"; git config user.email \"you@example.com\""
