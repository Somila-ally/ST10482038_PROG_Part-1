﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace ChatbotProject
{
    class Program
    {
        static void Main(string[] args)
        {
            var audio = new AudioPlayer();
            var user = new User();
            var bot = new Chatbot(user);

            // Display logo and greeting
            bot.DisplayLogo();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Please enter your name to continue: ");
            string name = Console.ReadLine() ?? "User";
            while (string.IsNullOrWhiteSpace(name))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Name cannot be empty. Please try again.");
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("Please enter your name: ");
                name = Console.ReadLine() ?? "User";
            }
            user.Name = name.Trim();
            Console.ResetColor();

            // Voice greeting
            string greeting = $"Hello {user.Name}. Welcome to the Cybersecurity Awareness Bot. I'm here to help you stay safe online.";
            bot.TypeEffect($"\nBot: {greeting}", 10);
            audio.SpeakAsync(greeting);

            bot.DisplayMenu(user.Name);

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write($"\n{user.Name}'s Choice > ");
                string input = (Console.ReadLine() ?? string.Empty).Trim();
                Console.ResetColor();

                if (string.Equals(input, "menu", StringComparison.OrdinalIgnoreCase))
                {
                    bot.DisplayMenu(user.Name);
                    continue;
                }

                if (string.Equals(input, "exit", StringComparison.OrdinalIgnoreCase) || input == "5")
                {
                    string bye = $"Goodbye, {user.Name}! Remember to stay vigilant online.";
                    bot.TypeEffect($"\nBot: {bye}", 20);
                    audio.SpeakAsync(bye);
                    break;
                }

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error: Input cannot be empty.");
                    Console.ResetColor();
                    continue;
                }

                string response = bot.GetResponse(input);
                bot.DisplayBotResponse(response);
                audio.SpeakAsync(response);
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.WriteLine("Hint: Type 'menu' to see options, or ask me about 'passwords', 'phishing', etc.");
                Console.ResetColor();
            }
        }
    }
}
